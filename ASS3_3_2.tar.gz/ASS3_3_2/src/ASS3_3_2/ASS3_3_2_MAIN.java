package ASS3_3_2;

import java.io.*;
import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.io.LongWritable;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.jobhistory.MapAttemptFinished;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class ASS3_3_2_MAIN 
{
	public  static class ASS3_3_2_MAP extends Mapper<LongWritable, Text, Text, Text>
	{
		public void map(LongWritable key, Text Value,Context context) throws IOException, InterruptedException
		{
			String line[] = Value.toString().split("|");
			Text com = new Text(line[0]);
			Text pro = new Text(line[1]);
			
			if (!com.equals("NA")){
				context.write(com, pro);
			}
			
			
		}
	}
		public  static class ASS3_3_2_RED extends Reducer<Text, Text, Text, IntWritable>
		{
			public void red(Text key, Iterable<Text> Values,Context context) throws IOException, InterruptedException
			{
				int count=0;
				for(Text value : Values)
				{
					count+=1;
				}
				context.write(key, new IntWritable(count));
				
			}
		}
	
	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		Configuration conf = new Configuration();

	    @SuppressWarnings("deprecation")
		Job job = new Job(conf, "Sold Product Count for each company");

	    job.setJarByClass(ASS3_3_2_MAIN.class);

	    job.setMapperClass(ASS3_3_2_MAP.class);

   

	    job.setReducerClass(ASS3_3_2_RED.class);

	    job.setOutputKeyClass(Text.class);

	    job.setOutputValueClass(IntWritable.class);

	    FileInputFormat.addInputPath(job, new Path(args[0]));

	    FileOutputFormat.setOutputPath(job, new Path(args[1]));

	    job.waitForCompletion(true);

	}

}


